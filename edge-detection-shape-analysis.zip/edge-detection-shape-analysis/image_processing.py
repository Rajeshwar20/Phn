"""Reusable image processing functions for Edge Detection & Shape Analysis."""
import math

import cv2
import numpy as np


def preprocess_image(image):
    """Convert to grayscale and blur to reduce noise."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    return gray, blurred


def detect_edges(image, low=50, high=150):
    """Canny edge detection."""
    return cv2.Canny(image, low, high)


def apply_morphology(edges, kernel_size=5):
    """Close gaps in edges so each object forms one closed contour."""
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
    return cv2.dilate(closed, kernel, iterations=1)


def detect_shape(contour):
    """Classify a contour by its corner count and circularity."""
    peri = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.04 * peri, True)
    n = len(approx)

    if n == 3:
        return "Triangle"
    if n == 4:
        _, _, w, h = cv2.boundingRect(approx)
        return "Square" if 0.95 <= w / float(h) <= 1.05 else "Rectangle"
    if n == 5:
        return "Pentagon"

    area = cv2.contourArea(contour)
    circularity = 4 * math.pi * area / (peri * peri) if peri else 0
    return "Circle" if circularity > 0.8 else "Polygon"


def detect_objects(edges, original, min_area=500):
    """Find contours, draw boxes + labels, return (image, count, details)."""
    contours, _ = cv2.findContours(
        edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    details = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < min_area:
            continue

        shape = detect_shape(contour)
        x, y, w, h = cv2.boundingRect(contour)
        idx = len(details) + 1
        details.append({"id": idx, "shape": shape, "area": int(area),
                        "bbox": (x, y, w, h)})

        cv2.rectangle(original, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(original, f"#{idx} {shape} | {int(area)} px",
                    (x, max(y - 10, 15)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (0, 255, 0), 2)

    return original, len(details), details
