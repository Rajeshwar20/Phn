import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from image_processing import detect_shape


def _contour(points):
    return np.array(points, np.int32).reshape(-1, 1, 2)


def test_triangle():
    assert detect_shape(_contour([[0, 100], [50, 0], [100, 100]])) == "Triangle"


def test_square():
    assert detect_shape(_contour([[0, 0], [100, 0], [100, 100], [0, 100]])) == "Square"


def test_rectangle():
    assert detect_shape(_contour([[0, 0], [200, 0], [200, 80], [0, 80]])) == "Rectangle"


def test_circle():
    canvas = np.zeros((200, 200), np.uint8)
    cv2.circle(canvas, (100, 100), 60, 255, -1)
    cnts, _ = cv2.findContours(canvas, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    assert detect_shape(cnts[0]) == "Circle"
