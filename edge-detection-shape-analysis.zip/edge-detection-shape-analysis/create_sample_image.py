"""Generate a sample test image (images/objects.jpg) with known shapes."""
import os

import cv2
import numpy as np

os.makedirs("images", exist_ok=True)
img = np.full((400, 600, 3), 255, np.uint8)

cv2.rectangle(img, (40, 40), (180, 180), (0, 0, 0), -1)          # square
cv2.rectangle(img, (230, 50), (430, 150), (60, 60, 200), -1)     # rectangle
cv2.circle(img, (520, 110), 60, (200, 80, 40), -1)               # circle
tri = np.array([[110, 380], [40, 250], [180, 250]], np.int32)
cv2.fillPoly(img, [tri], (30, 150, 30))                          # triangle
pent = np.array([[330, 240], [390, 285], [365, 355],
                 [295, 355], [270, 285]], np.int32)
cv2.fillPoly(img, [pent], (0, 140, 220))                         # pentagon

cv2.imwrite("images/objects.jpg", img)
print("Created images/objects.jpg")
