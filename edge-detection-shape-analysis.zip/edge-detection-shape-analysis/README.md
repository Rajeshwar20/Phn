# Edge Detection & Shape Analysis System

Part of the **AI Image Enhancement Toolkit** (Chapter 2: Digital Image Processing & Image Enhancement).

Detects objects in an image, draws bounding boxes, classifies their shapes and reports each object's area.

## Pipeline

```
Image -> Grayscale -> Gaussian Blur -> Canny Edges -> Morphology -> Contours -> Shape Detection
```

## Features
- Noise removal (Gaussian blur)
- Canny edge detection
- Morphological closing + dilation to fix broken edges
- Contour detection with bounding boxes
- Shape classification: Triangle, Square, Rectangle, Pentagon, Circle
- Per-object area and total object count
- Modular design: `image_processing.py` (functions) + `main.py` (pipeline/CLI)

## Project Structure
```
edge-detection-shape-analysis/
├── main.py
├── image_processing.py
├── create_sample_image.py
├── requirements.txt
├── images/objects.jpg
├── output/
└── tests/test_shapes.py
```

## Setup
```bash
git clone https://github.com/Rajeshwar20/edge-detection-shape-analysis.git
cd edge-detection-shape-analysis
pip install -r requirements.txt
```

## Usage
```bash
python create_sample_image.py            # optional: makes a test image
python main.py                           # uses images/objects.jpg
python main.py --image images/my.jpg --min-area 800
python main.py --no-display              # Colab / server / phone
```
Results are saved to `output/detected_objects.jpg` and `output/edges.jpg`.

## Sample Output
```
Number of detected objects: 5
Object 1: Triangle   area = 10592 px
Object 2: Pentagon   area = 10592 px
...
```

## Tests
```bash
pytest
```

## Tech
Python, OpenCV, NumPy, Git, GitHub, VS Code
