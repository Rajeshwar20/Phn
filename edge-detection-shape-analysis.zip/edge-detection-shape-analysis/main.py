"""Program 3: Edge Detection & Shape Analysis System.

Pipeline: Image -> Grayscale -> Blur -> Canny -> Morphology -> Contours -> Shapes
"""
import argparse
import os
import sys

import cv2

from image_processing import (
    preprocess_image,
    detect_edges,
    apply_morphology,
    detect_objects,
)


def parse_args():
    p = argparse.ArgumentParser(description="Edge detection & shape analysis")
    p.add_argument("--image", default="images/objects.jpg", help="input image")
    p.add_argument("--output", default="output/detected_objects.jpg",
                   help="where to save the result")
    p.add_argument("--min-area", type=int, default=500,
                   help="ignore objects smaller than this (pixels)")
    p.add_argument("--no-display", action="store_true",
                   help="skip cv2.imshow windows (for servers/Colab/phones)")
    return p.parse_args()


def main():
    args = parse_args()

    image = cv2.imread(args.image)
    if image is None:
        print(f"Error: image not found: {args.image}")
        sys.exit(1)

    gray, blurred = preprocess_image(image)
    edges = detect_edges(blurred)
    morph = apply_morphology(edges)
    result, count, details = detect_objects(morph, image.copy(), args.min_area)

    print(f"Number of detected objects: {count}")
    for d in details:
        print(f"Object {d['id']}: {d['shape']:<10} area = {d['area']} px")

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    cv2.imwrite(args.output, result)
    cv2.imwrite("output/edges.jpg", morph)
    print(f"Saved result to {args.output}")

    if not args.no_display:
        cv2.imshow("Original Image", image)
        cv2.imshow("Edges (after morphology)", morph)
        cv2.imshow("Detected Objects", result)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
